# coding = utf-8
BASE_URL = "http://httpbin.org/"
IP_URL = "/ip"
LOCAL_IP = "112.96.104.98"
POST_TEST_URL = "/post"